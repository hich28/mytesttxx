#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <setjmp.h>

typedef uint64_t ulong_long_int_t;
typedef int64_t slong_long_int_t;
typedef uint32_t ulong_int_t;
typedef int32_t slong_int_t;
typedef union
{
    uint16_t var;
    uint32_t __padding__;
} ushort_int_t;
typedef union
{
    int16_t var;
    uint32_t __padding__;
} sshort_int_t;
typedef union
{
    uint8_t var;
    uint32_t __padding__;
} ubyte_t;
typedef ubyte_t byte_t;
typedef union
{
    int8_t var;
    uint32_t __padding__;
} sbyte_t;
typedef size_t size_int_t;

typedef struct transition_info
{
    int* label;
    int  group;
    int  por_proviso;
} transition_info_t;


struct state_struct_t
{
    sshort_int_t a;
    sshort_int_t b;
    struct
    {
        ushort_int_t state;
    }
    __attribute__((__packed__)) P;
    struct
    {
        ushort_int_t state;
    }
    __attribute__((__packed__)) Q;
}
__attribute__((__packed__));
int state_size = sizeof(state_struct_t);

state_struct_t initial_state = { 0,0,0,0 };

extern "C" int get_state_size() {
    return state_size;
}

extern "C" void get_initial_state( void *to )
{
    memcpy(to, &initial_state, state_size);
}

extern "C" int have_property()
{
    return false;
}

extern "C" int get_action( void* model, int t, const state_struct_t *in, void (*callback)(void* arg, transition_info_t *transition_info, state_struct_t *out, int *cpy), void *arg ) 
{
    transition_info_t transition_info = { NULL, t, 0 };
    (void)model; // ignore model
    int states_emitted = 0;
    state_struct_t tmp;
    state_struct_t *out = &tmp;
    int cpy[4] = { 1,1,1,1,};
    goto switch_state;
    l0: {
        *out = *in;
        (*out).P.state.var = 0;
        cpy[((int*)&(*out).P.state.var - (int*)&(*out))] = 0;
        ((*out).a.var = (*out).a.var + 1);
        cpy[((int*)&((*out).a.var) - (int*)&(*out))] = 0;
        // actions_read: 1,0,0,0
        // may-write:    1,0,1,0
        // must-write:   1,0,1,0
        callback(arg, &transition_info, out, cpy);
        ++states_emitted;
    }
    return states_emitted;
    l1: {
        *out = *in;
        (*out).P.state.var = 0;
        cpy[((int*)&(*out).P.state.var - (int*)&(*out))] = 0;
        ((*out).b.var = (*out).b.var + 1);
        cpy[((int*)&((*out).b.var) - (int*)&(*out))] = 0;
        // actions_read: 0,1,0,0
        // may-write:    0,1,1,0
        // must-write:   0,1,1,0
        callback(arg, &transition_info, out, cpy);
        ++states_emitted;
    }
    return states_emitted;
    l2: {
        *out = *in;
        (*out).Q.state.var = 1;
        cpy[((int*)&(*out).Q.state.var - (int*)&(*out))] = 0;
        // actions_read: 0,0,0,0
        // may-write:    0,0,0,1
        // must-write:   0,0,0,1
        callback(arg, &transition_info, out, cpy);
        ++states_emitted;
    }
    return states_emitted;
    l3: {
        *out = *in;
        (*out).Q.state.var = 0;
        cpy[((int*)&(*out).Q.state.var - (int*)&(*out))] = 0;
        // actions_read: 0,0,0,0
        // may-write:    0,0,0,1
        // must-write:   0,0,0,1
        callback(arg, &transition_info, out, cpy);
        ++states_emitted;
    }
    return states_emitted;
    switch_state: switch( t )
    {
        case 0: goto l0;
        case 1: goto l1;
        case 2: goto l2;
        case 3: goto l3;
        default: printf ("Wrong group! Using greybox/long call + -l (DiVinE LTL semantics)? This combo is not implemented."); exit (-1);
    }
    return 0;
}

extern "C" int get_successor( void* model, int t, const state_struct_t *in, void (*callback)(void* arg, transition_info_t *transition_info, state_struct_t *out, int *cpy), void *arg ) 
{
    int states_emitted = 0;
    goto switch_state;
    l0: {
        
        // read:         1,1,1,0
        // actions_read: 1,0,0,0
        if (  ( ((*in).P.state.var == 0) )  &&  ( ((*in).a.var < 3 && (*in).b.var < 3) ) )
        states_emitted = get_action(model, t, in, callback, arg);
    }
    return states_emitted;
    l1: {
        
        // read:         1,1,1,0
        // actions_read: 0,1,0,0
        if (  ( ((*in).P.state.var == 0) )  &&  ( ((*in).a.var < 3 && (*in).b.var < 3) ) )
        states_emitted = get_action(model, t, in, callback, arg);
    }
    return states_emitted;
    l2: {
        
        // read:         0,1,0,1
        // actions_read: 0,0,0,0
        if (  ( ((*in).Q.state.var == 0) )  &&  ( ((*in).b.var > 1) ) )
        states_emitted = get_action(model, t, in, callback, arg);
    }
    return states_emitted;
    l3: {
        
        // read:         1,0,0,1
        // actions_read: 0,0,0,0
        if (  ( ((*in).Q.state.var == 1) )  &&  ( ((*in).a.var > 1) ) )
        states_emitted = get_action(model, t, in, callback, arg);
    }
    return states_emitted;
    switch_state: switch( t )
    {
        case 0: goto l0;
        case 1: goto l1;
        case 2: goto l2;
        case 3: goto l3;
        default: printf ("Wrong group! Using greybox/long call + -l (DiVinE LTL semantics)? This combo is not implemented."); exit (-1);
    }
    return 0;
}

extern "C" int get_successors( void *model, const state_struct_t *in, void (*callback)(void *arg, transition_info_t *transition_info, state_struct_t *out, int *cpy), void *arg ) 
{
    (void)model; // ignore model
    bool system_in_deadlock = true;
    transition_info_t transition_info = { NULL, -1, 0 };
    int states_emitted = 0;
    state_struct_t tmp;
    state_struct_t *out = &tmp;
    int cpy[4] = { 1, 1, 1, 1, };
    if ( false )
    {
        ;
    }
    else
    {
        if (  ( ((*in).P.state.var == 0) ) )
        {
            
            // read:         1,1,1,0
            // actions_read: 1,0,0,0
            if (  ( ((*in).a.var < 3 && (*in).b.var < 3) ) )
            {
                *out = *in;
                (*out).P.state.var = 0;
                cpy[((int*)&(*out).P.state.var - (int*)&(*out))] = 0;
                ((*out).a.var = (*out).a.var + 1);
                cpy[((int*)&((*out).a.var) - (int*)&(*out))] = 0;
                // actions_read: 1,0,0,0
                // may-write:    1,0,1,0
                // must-write:   1,0,1,0
                system_in_deadlock = false;
                transition_info.group = 0;
                callback(arg, &transition_info, out, cpy);
                ++states_emitted;
            }
            
            // read:         1,1,1,0
            // actions_read: 0,1,0,0
            if (  ( ((*in).a.var < 3 && (*in).b.var < 3) ) )
            {
                *out = *in;
                (*out).P.state.var = 0;
                cpy[((int*)&(*out).P.state.var - (int*)&(*out))] = 0;
                ((*out).b.var = (*out).b.var + 1);
                cpy[((int*)&((*out).b.var) - (int*)&(*out))] = 0;
                // actions_read: 0,1,0,0
                // may-write:    0,1,1,0
                // must-write:   0,1,1,0
                system_in_deadlock = false;
                transition_info.group = 1;
                callback(arg, &transition_info, out, cpy);
                ++states_emitted;
            }
        }
        if (  ( ((*in).Q.state.var == 0) ) )
        {
            
            // read:         0,1,0,1
            // actions_read: 0,0,0,0
            if (  ( ((*in).b.var > 1) ) )
            {
                *out = *in;
                (*out).Q.state.var = 1;
                cpy[((int*)&(*out).Q.state.var - (int*)&(*out))] = 0;
                // actions_read: 0,0,0,0
                // may-write:    0,0,0,1
                // must-write:   0,0,0,1
                system_in_deadlock = false;
                transition_info.group = 2;
                callback(arg, &transition_info, out, cpy);
                ++states_emitted;
            }
        }
        if (  ( ((*in).Q.state.var == 1) ) )
        {
            
            // read:         1,0,0,1
            // actions_read: 0,0,0,0
            if (  ( ((*in).a.var > 1) ) )
            {
                *out = *in;
                (*out).Q.state.var = 0;
                cpy[((int*)&(*out).Q.state.var - (int*)&(*out))] = 0;
                // actions_read: 0,0,0,0
                // may-write:    0,0,0,1
                // must-write:   0,0,0,1
                system_in_deadlock = false;
                transition_info.group = 3;
                callback(arg, &transition_info, out, cpy);
                ++states_emitted;
            }
        }
    }
    if (  ( system_in_deadlock ) )
    {
    }
    return states_emitted;
}

extern "C" int get_state_variable_count() 
{
    return 4;
}

extern "C" const char* get_state_variable_name(int var)
{
    switch (var)
    {
        case 0:
            return "a";
        case 1:
            return "b";
        case 2:
            return "P";
        case 3:
            return "Q";
        default:
            return NULL;
    }
}

extern "C" int get_state_variable_type(int var)
{
    switch (var)
    {
        case 0:
            return 0;
        case 1:
            return 0;
        case 2:
            return 1;
        case 3:
            return 2;
        default:
            return -1;
    }
}

extern "C" int get_state_variable_type_count() 
{
    return 3;
}

extern "C" const char* get_state_variable_type_name(int type) 
{
    switch (type)
    {
        case 1:
            return "P";
        case 2:
            return "Q";
        case 0:
            return "int";
        default:
            return NULL;
    }
}

extern "C" int get_state_variable_type_value_count(int type)
{
    switch (type)
    {
        case 1: // P
            return 1;
        case 2: // Q
            return 2;
        case 0: // int
            return 0;
        default:
            return -1;
    }
}

extern "C" const char* get_state_variable_type_value(int type, int value) 
{
    switch (type)
    {
        case 1:
        {
            switch (value)
            {
                case 0:
                    return "x";
            }
        }
        case 2:
        {
            switch (value)
            {
                case 0:
                    return "wait";
                case 1:
                    return "work";
            }
        }
    }
    return NULL;
}

int transition_dependency[][3][4] = 
{
    // { ... read ...}, { ... may-write ...}, { ... must-write ...}
    {{1,1,1,0},{1,0,1,0},{1,0,1,0}},
    {{1,1,1,0},{0,1,1,0},{0,1,1,0}},
    {{0,1,0,1},{0,0,0,1},{0,0,0,1}},
    {{1,0,0,1},{0,0,0,1},{0,0,0,1}}
}
;

int actions_read[][4] = 
{
    {1,0,0,0},
    {0,1,0,0},
    {0,0,0,0},
    {0,0,0,0}
}
;

extern "C" int get_transition_count() 
{
    return 4;
}

extern "C" const int* get_transition_read_dependencies(int t) 
{
    if (t>=0 && t < 4) return transition_dependency[t][0];
    return NULL;
}

extern "C" const int* get_transition_actions_read_dependencies(int t) 
{
    if (t>=0 && t < 4) return actions_read[t];
    return NULL;
}

extern "C" const int* get_transition_may_write_dependencies(int t) 
{
    if (t>=0 && t < 4) return transition_dependency[t][1];
    return NULL;
}

extern "C" const int* get_transition_write_dependencies(int t) 
{
    return get_transition_may_write_dependencies(t);
}

extern "C" const int* get_transition_must_write_dependencies(int t) 
{
    if (t>=0 && t < 4) return transition_dependency[t][2];
    return NULL;
}

extern "C" int get_active( state_struct_t *in, int t ) 
{
    switch(t)
    {
        case 0: return (((*in).P.state.var == 0));
        case 1: return (((*in).P.state.var == 0));
        case 2: return (((*in).Q.state.var == 0));
        case 3: return (((*in).Q.state.var == 1));
    }
    return false;
}

extern "C" void get_group_pid_lid( int t, int* pid0, int* lid0, int* pid1, int* lid1 ) 
{
    switch(t)
    {
        case 0: *pid0 = 0; *lid0 = 0; *pid1 = -1; *lid1 = -1; return;
        case 1: *pid0 = 0; *lid0 = 0; *pid1 = -1; *lid1 = -1; return;
        case 2: *pid0 = 1; *lid0 = 0; *pid1 = -1; *lid1 = -1; return;
        case 3: *pid0 = 1; *lid0 = 1; *pid1 = -1; *lid1 = -1; return;
    }
    *pid0 = *lid0 = -1;
    *pid1 = *lid0 = -1;
    return;
}

static int wrapped_div(int denom, jmp_buf* jbuf)
{
    if(denom == 0) longjmp(*jbuf, 1);
    return denom;
}

static int wrapped_index(int index, int size, jmp_buf* jbuf)
{
    if(index < 0 || index >= size) longjmp(*jbuf, 1);
    return index;
}

extern "C" int get_guard(void* model, int g, state_struct_t* src) 
{
    (void)model;
    jmp_buf jbuf;
    if(!setjmp(jbuf))
    {
        switch(g)
        {
            case 0: return (((*src).P.state.var == 0));
            case 1: return (((*src).a.var < 3));
            case 2: return (((*src).b.var < 3));
            case 3: return (((*src).Q.state.var == 0));
            case 4: return (((*src).b.var > 1));
            case 5: return (((*src).Q.state.var == 1));
            case 6: return (((*src).a.var > 1));
        }
    }
    else return 2;
    return false;
}

extern "C" void get_guard_all(void* model, state_struct_t* src, int* guard) 
{
    guard[0] = get_guard(model, 0, src);
    guard[1] = get_guard(model, 1, src);
    guard[2] = get_guard(model, 2, src);
    guard[3] = get_guard(model, 3, src);
    guard[4] = get_guard(model, 4, src);
    guard[5] = get_guard(model, 5, src);
    guard[6] = get_guard(model, 6, src);
}

extern "C" const int get_guard_count() 
{
    return 7;
}

int* guards_per_transition[4] = 
{
    ((int[]){3, 0, 1, 2}), // 0
    ((int[]){3, 0, 1, 2}), // 1
    ((int[]){2, 3, 4}), // 2
    ((int[]){2, 5, 6}), // 3
}
;

extern "C" const int* get_guards(int t) 
{
    if (t>=0 && t < 4) return guards_per_transition[t];
    return NULL;
}

extern "C" const int** get_all_guards() 
{
    return (const int**)&guards_per_transition;
}

int guard[][4] = 
{
    {0,0,1,0},
    {1,0,0,0},
    {0,1,0,0},
    {0,0,0,1},
    {0,1,0,0},
    {0,0,0,1},
    {1,0,0,0}
}
;

extern "C" const int* get_guard_matrix(int g) 
{
    if (g>=0 && g < 7) return guard[g];
    return NULL;
}

int guardmaybecoenabled[7][7] = 
{
    {1, 1, 1, 1, 1, 1, 1},
    {1, 1, 1, 1, 1, 1, 1},
    {1, 1, 1, 1, 1, 1, 1},
    {1, 1, 1, 1, 1, 0, 1},
    {1, 1, 1, 1, 1, 1, 1},
    {1, 1, 1, 0, 1, 1, 1},
    {1, 1, 1, 1, 1, 1, 1}
}
;

extern "C" const int* get_guard_may_be_coenabled_matrix(int g) 
{
    if (g>=0 && g < 7) return guardmaybecoenabled[g];
    return NULL;
}

int guard_nes[7][4] = 
{
    {1, 1, 0, 0},
    {1, 1, 1, 1},
    {1, 1, 1, 1},
    {0, 0, 0, 1},
    {1, 1, 1, 1},
    {0, 0, 1, 0},
    {1, 1, 1, 1}
}
;

extern "C" const int* get_guard_nes_matrix(int g) 
{
    if (g>=0 && g < 7) return guard_nes[g];
    return NULL;
}

int guard_nds[7][4] = 
{
    {0, 0, 0, 0},
    {1, 1, 1, 1},
    {1, 1, 1, 1},
    {0, 0, 1, 0},
    {1, 1, 1, 1},
    {0, 0, 0, 1},
    {1, 1, 1, 1}
}
;

extern "C" const int* get_guard_nds_matrix(int g) 
{
    if (g>=0 && g < 7) return guard_nds[g];
    return NULL;
}

int dna[4][4] = 
{
    {1, 1, 1, 1},
    {1, 1, 1, 1},
    {1, 1, 1, 1},
    {1, 1, 1, 1}
}
;

extern "C" const int* get_dna_matrix(int t) 
{
    if (t >= 0 && t < 4) return dna[t];
    return NULL;
}

